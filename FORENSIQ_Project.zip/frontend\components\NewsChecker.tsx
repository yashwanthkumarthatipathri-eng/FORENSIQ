﻿"use client";

import { useState } from "react";
import { 
  Search, ExternalLink, AlertCircle, AlertTriangle, 
  XCircle, CheckCircle2, Sparkles, RefreshCw, Globe, HelpCircle 
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";

interface NewsResult {
  truthfulness_score: number;
  identified_discrepancies: string[];
  verified_news_references: Array<{
    title: string;
    snippet: string;
    link: string;
  }>;
}

const PRESET_CLAIMS = [
  { label: "Mars Liquid Water", claim: "NASA rover discovers active subterranean liquid water on Mars" },
  { label: "Politician Emergency (False)", claim: "World leader announces sudden overnight emergency currency replacement" },
  { label: "Free Energy Machine (False)", claim: "Scientists invent free infinite zero-point energy machine suppressed by oil companies" },
  { label: "WHO Health Update", claim: "World Health Organization releases official update on global seasonal respiratory infections" },
];

export default function NewsChecker() {
  const [claim, setClaim] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<NewsResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async (overrideClaim?: string) => {
    const targetClaim = overrideClaim !== undefined ? overrideClaim : claim;
    if (!targetClaim.trim()) return;
    
    setIsVerifying(true);
    setError(null);
    setResult(null);
    
    try {
      const res = await axios.post("/api/verify/news", { claim: targetClaim });
      setResult(res.data);
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.detail || err.response?.data?.error || "Failed to verify the claim. Please try again.");
      } else {
        setError("An unexpected error occurred while connecting to the news verification engine.");
      }
    } finally {
      setIsVerifying(false);
    }
  };

  const selectPreset = (presetText: string) => {
    setClaim(presetText);
    handleVerify(presetText);
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.7) return {
      border: "border-success/30",
      bg: "bg-success/10",
      text: "text-success",
      badge: "bg-success/20 text-success border-success/30"
    };
    if (score > 0.0) return {
      border: "border-yellow-400/30",
      bg: "bg-yellow-400/10",
      text: "text-yellow-400",
      badge: "bg-yellow-400/20 text-yellow-400 border-yellow-400/30"
    };
    // Score == 0.0 (FALSE / DEBUNKED)
    return {
      border: "border-destructive/40",
      bg: "bg-destructive/15",
      text: "text-destructive",
      badge: "bg-destructive/25 text-destructive border-destructive/40"
    };
  };

  const getScoreLabel = (score: number) => {
    if (score >= 0.7) return "Verified Authentic";
    if (score > 0.0) return "Mixed / Unverified";
    return "FALSE / DEBUNKED (0%)";
  };

  const scoreTheme = result ? getScoreColor(result.truthfulness_score) : null;

  return (
    <div className="w-full flex flex-col gap-6">
      {/* Input Area */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-foreground/40" />
          </div>
          <input
            type="text"
            className="w-full pl-12 pr-10 py-3.5 bg-secondary/30 border border-white/10 rounded-xl text-foreground placeholder:text-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all text-sm"
            placeholder="Paste a statement, headline, or news link to cross-examine..."
            value={claim}
            onChange={(e) => setClaim(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
          />
          {claim && (
            <button
              onClick={() => setClaim("")}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-foreground/40 hover:text-foreground"
            >
              <XCircle className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          onClick={() => handleVerify()}
          disabled={!claim.trim() || isVerifying}
          className="px-8 py-3.5 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_15px_rgba(59,130,246,0.3)] whitespace-nowrap text-sm flex items-center justify-center gap-2"
        >
          {isVerifying ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Verifying Live Feeds...
            </>
          ) : (
            <>
              <Globe className="w-4 h-4" />
              Verify Claim
            </>
          )}
        </button>
      </div>

      {/* Preset Pill Chips */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-foreground/50 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
          Quick Test Examples:
        </span>
        {PRESET_CLAIMS.map((p, idx) => (
          <button
            key={idx}
            onClick={() => selectPreset(p.claim)}
            className="px-3 py-1 bg-secondary/30 hover:bg-primary/15 hover:text-primary text-foreground/70 rounded-full border border-white/5 transition-all text-xs"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Error Message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="text-sm text-destructive flex items-center gap-2 bg-destructive/10 p-4 rounded-xl border border-destructive/20"
          >
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Dashboard */}
      <AnimatePresence>
        {result && scoreTheme && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6 mt-4"
          >
            {/* Top Verification Header */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/50 uppercase tracking-widest">
                Cross-Reference Analysis
              </span>
              <button
                onClick={() => { setResult(null); setClaim(""); }}
                className="text-xs text-foreground/50 hover:text-foreground flex items-center gap-1.5 px-3 py-1 bg-secondary/30 rounded-lg hover:bg-secondary/50 transition-all border border-white/5"
              >
                <RefreshCw className="w-3 h-3" />
                Clear Analysis
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Radial Truth Score */}
              <div className="lg:col-span-4 glass-card flex flex-col items-center justify-center text-center p-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-60"></div>
                <p className="text-xs font-semibold text-foreground/60 uppercase tracking-widest mb-4">
                  Truthfulness Rating
                </p>
                
                {/* Circular Score Visual */}
                <div className={`w-32 h-32 rounded-full flex flex-col items-center justify-center border-4 ${scoreTheme.border} ${scoreTheme.bg} mb-4 shadow-xl relative`}>
                  <span className={`text-4xl font-black ${scoreTheme.text}`}>
                    {(result.truthfulness_score * 100).toFixed(0)}%
                  </span>
                  <span className="text-[10px] uppercase tracking-wider text-foreground/60 mt-0.5">
                    Confidence
                  </span>
                </div>
                
                <div className={`px-4 py-1.5 rounded-full border text-xs font-bold ${scoreTheme.badge} uppercase tracking-wider mb-2`}>
                  {getScoreLabel(result.truthfulness_score)}
                </div>

                <p className="text-xs text-foreground/50 max-w-xs mt-2">
                  Corroborated across real-time syndicated news reports, fact-check feeds, and credibility heuristics.
                </p>
              </div>

              {/* Right Column: Identified Discrepancies & Sources */}
              <div className="lg:col-span-8 flex flex-col gap-5">
                {/* Discrepancies */}
                {result.identified_discrepancies.length > 0 && (
                  <div className="glass-card">
                    <h4 className="text-sm font-bold text-foreground/90 flex items-center gap-2 mb-3">
                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      Factual Evaluation & Discrepancy Findings
                    </h4>
                    <ul className="space-y-2.5">
                      {result.identified_discrepancies.map((d, i) => (
                        <li key={i} className="flex items-start gap-3 bg-secondary/20 p-3 rounded-lg border border-white/5 text-xs text-foreground/85 leading-relaxed">
                          {result.truthfulness_score >= 0.7 ? (
                            <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-0.5" />
                          ) : result.truthfulness_score > 0.0 ? (
                            <HelpCircle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                          ) : (
                            <XCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                          )}
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Verified References */}
                {result.verified_news_references.length > 0 && (
                  <div className="glass-card">
                    <h4 className="text-sm font-bold text-foreground/90 flex items-center gap-2 mb-3">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      Live Verified References & Citations
                    </h4>
                    <div className="flex flex-col gap-2.5">
                      {result.verified_news_references.map((ref, i) => (
                        <a 
                          key={i} 
                          href={ref.link} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="block bg-secondary/20 p-3.5 rounded-xl border border-white/5 hover:border-primary/40 hover:bg-secondary/40 transition-all group"
                        >
                          <div className="flex justify-between items-start gap-4">
                            <div className="overflow-hidden">
                              <h5 className="font-semibold text-xs text-primary group-hover:underline mb-1 truncate">
                                {ref.title}
                              </h5>
                              <p className="text-xs text-foreground/60 line-clamp-2 leading-relaxed">
                                {ref.snippet}
                              </p>
                            </div>
                            <ExternalLink className="w-4 h-4 text-foreground/30 group-hover:text-primary shrink-0 mt-0.5" />
                          </div>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
