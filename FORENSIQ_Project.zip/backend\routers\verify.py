﻿from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel, Field
from services.news_engine import news_engine
from services.media_engine import media_engine

router = APIRouter()

class ClaimRequest(BaseModel):
    claim: str = Field(default="", description="Claim text or news headline to verify")

@router.post("/news")
async def verify_news(request: ClaimRequest):
    """
    Endpoint to verify a text claim or URL against live news sources.
    """
    cleaned = request.claim.strip()
    if not cleaned:
        raise HTTPException(status_code=400, detail="Claim cannot be empty")
        
    result = await news_engine.verify_claim(cleaned)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
        
    return result

@router.post("/media")
async def verify_media(file: UploadFile = File(...)):
    """
    Endpoint to verify an uploaded image or video for digital manipulation and deepfake artifacts.
    """
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")
        
    file_bytes = await file.read()
    if len(file_bytes) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes)")

    content_type = file.content_type or ""
    filename_lower = file.filename.lower()

    # Check for video types
    is_video = (
        content_type.startswith("video/") or 
        filename_lower.endswith((".mp4", ".mov", ".avi", ".webm", ".mkv"))
    )

    # Check for image types
    is_image = (
        content_type.startswith("image/") or 
        filename_lower.endswith((".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"))
    )

    if is_video:
        result = await media_engine.analyze_video(file_bytes, file.filename)
    elif is_image:
        result = await media_engine.analyze_image(file_bytes, file.filename)
    else:
        # Fallback: attempt image analysis first
        try:
            result = await media_engine.analyze_image(file_bytes, file.filename)
        except Exception:
            raise HTTPException(status_code=400, detail="Unsupported file format. Please upload an image or video.")
         
    return result

@router.get("/samples")
async def get_samples():
    """
    Provides pre-configured verified and disputed test cases for rapid frontend evaluation.
    """
    return {
        "claims": [
            {
                "label": "NASA Mars Discovery",
                "text": "NASA's Perseverance rover discovers evidence of active subterranean liquid water on Mars",
                "category": "Science"
            },
            {
                "label": "Deepfake Politician Video",
                "text": "Viral video falsely claiming world leader announced nationwide emergency currency change",
                "category": "Politics"
            },
            {
                "label": "Free Energy Breakthrough",
                "text": "Scientists discover perpetual zero-point free electricity engine hidden by corporations",
                "category": "Debunked"
            },
            {
                "label": "WHO Global Advisory",
                "text": "World Health Organization releases official update on seasonal respiratory infection trends",
                "category": "Health"
            }
        ]
    }
