﻿@echo off
title AI M0DULE - Next.js Frontend (Port 3000)
cd /d "%~dp0frontend"
set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
echo ========================================================
echo Starting AI M0DULE Next.js Web Interface on port 3000...
echo Web App: http://localhost:3000
echo ========================================================
call "%LOCALAPPDATA%\Programs\nodejs\npm.cmd" run dev
pause
