﻿import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw
from main import app
from services.news_engine import news_engine
from services.media_engine import media_engine

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "AI M0DULE Backend"

def test_verify_news_empty_claim():
    response = client.post("/api/verify/news", json={"claim": ""})
    assert response.status_code == 400

def test_verify_news_whitespace_claim():
    response = client.post("/api/verify/news", json={"claim": "   "})
    assert response.status_code == 400

@pytest.mark.asyncio
async def test_mock_news_verification(monkeypatch):
    """Test the news verification endpoint with mocked LLM response."""
    async def mock_verify(claim):
        return {
            "truthfulness_score": 0.85,
            "identified_discrepancies": ["Corroborated by AP and Reuters."],
            "verified_news_references": [
                {"title": "Test Title", "snippet": "Test snippet", "link": "https://example.com"}
            ]
        }
        
    monkeypatch.setattr(news_engine, "verify_claim", mock_verify)
    
    response = client.post("/api/verify/news", json={"claim": "Test verified claim"})
    assert response.status_code == 200
    data = response.json()
    assert data["truthfulness_score"] == 0.85
    assert len(data["identified_discrepancies"]) == 1
    assert len(data["verified_news_references"]) == 1

@pytest.mark.asyncio
async def test_verify_media_with_mock(monkeypatch):
    """Test the media verification endpoint with a mock image analyze."""
    async def mock_analyze(file_bytes, filename):
        return {
            "status": "success",
            "filename": filename,
            "ai_probability": 0.12,
            "faces": [],
            "manipulation_heatmap": "data:image/jpeg;base64,mockbase64",
            "discrepancies": ["Test discrepancy"]
        }
        
    monkeypatch.setattr(media_engine, "analyze_image", mock_analyze)
    
    file_content = b"fake image data"
    files = {"file": ("test.jpg", io.BytesIO(file_content), "image/jpeg")}
    
    response = client.post("/api/verify/media", files=files)
    assert response.status_code == 200
    assert response.json()["ai_probability"] == 0.12

def test_verify_media_real_image():
    """Test full real end-to-end Error Level Analysis with real generated JPEG image."""
    img = Image.new("RGB", (120, 120), color=(100, 150, 200))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 80, 80], fill=(255, 100, 50))
    
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=95)
    buf.seek(0)
    
    files = {"file": ("real_test.jpg", buf, "image/jpeg")}
    response = client.post("/api/verify/media", files=files)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "ai_probability" in data
    assert "manipulation_heatmap" in data
    assert data["manipulation_heatmap"].startswith("data:image/jpeg;base64,")
    assert isinstance(data["discrepancies"], list)

def test_samples_endpoint():
    response = client.get("/api/verify/samples")
    assert response.status_code == 200
    data = response.json()
    assert "claims" in data
    assert len(data["claims"]) >= 3
