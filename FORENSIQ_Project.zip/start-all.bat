﻿@echo off
title AI M0DULE - Service Launcher
echo Starting AI M0DULE Backend and Frontend...
start "AI M0DULE Backend" cmd /c "%~dp0start-backend.bat"
timeout /t 2 /nobreak >nul
start "AI M0DULE Frontend" cmd /c "%~dp0start-frontend.bat"
echo Both services launched!
echo Backend: http://localhost:8000
echo Frontend: http://localhost:3000
