"use client";

import { useState, useCallback, useRef } from "react";
import { 
  UploadCloud, File as FileIcon, X, CheckCircle2, 
  AlertCircle, AlertTriangle, Scan, ShieldAlert, Sparkles, RefreshCw, Eye
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";

interface AnalysisResult {
  status: string;
  filename: string;
  ai_probability: number;
  faces: Array<{
    box: number[];
    attributes: { age: string; gender: string };
  }>;
  manipulation_heatmap: string;
  discrepancies: string[];
}

export default function UploadZone() {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<"heatmap" | "original">("heatmap");
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleFile(selectedFile: File) {
    if (selectedFile.size > 100 * 1024 * 1024) {
      setError("File size exceeds 100MB limit.");
      return;
    }
    setFile(selectedFile);
    setError(null);
    setResult(null);

    // Create a local blob preview
    if (selectedFile.type.startsWith("image/")) {
      const url = URL.createObjectURL(selectedFile);
      setPreviewUrl(url);
    } else {
      setPreviewUrl(null);
    }
  }

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const clearFile = () => {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Generate an instant synthetic sample image for testing
  const loadSampleImage = () => {
    const canvas = document.createElement("canvas");
    canvas.width = 400;
    canvas.height = 300;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Background gradient
    const grad = ctx.createLinearGradient(0, 0, 400, 300);
    grad.addColorStop(0, "#1e293b");
    grad.addColorStop(1, "#0f172a");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 400, 300);

    // Spliced patch (simulates high ELA anomaly)
    ctx.fillStyle = "#3b82f6";
    ctx.fillRect(50, 60, 140, 100);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 16px sans-serif";
    ctx.fillText("AI SPLICED LAYER", 60, 115);

    // Human silhouette boundary
    ctx.fillStyle = "#f59e0b";
    ctx.beginPath();
    ctx.arc(280, 120, 45, 0, Math.PI * 2);
    ctx.fill();

    canvas.toBlob((blob) => {
      if (blob) {
        const sampleFile = new File([blob], "evidence_sample.jpg", { type: "image/jpeg" });
        handleFile(sampleFile);
      }
    }, "image/jpeg", 0.92);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    
    setIsUploading(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    
    try {
      const res = await axios.post("/api/verify/media", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setResult(res.data);
      if (res.data.manipulation_heatmap) {
        setActiveView("heatmap");
      }
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.detail || "An error occurred during media analysis.");
      } else {
        setError("An unexpected error occurred connecting to the backend.");
      }
    } finally {
      setIsUploading(false);
    }
  };

  const getRiskColor = (prob: number) => {
    if (prob > 0.65) return "text-destructive border-destructive/30 bg-destructive/10";
    if (prob > 0.35) return "text-yellow-400 border-yellow-400/30 bg-yellow-400/10";
    return "text-success border-success/30 bg-success/10";
  };

  const getRiskLabel = (prob: number) => {
    if (prob > 0.65) return "High Risk of Manipulation";
    if (prob > 0.35) return "Suspicious / Moderate Distortion";
    return "Authentic / Consistent Media";
  };

  return (
    <div className="w-full">
      {/* Upload Box */}
      <div 
        className={`relative group flex flex-col items-center justify-center w-full min-h-[220px] p-6 border-2 border-dashed rounded-2xl transition-all duration-300 ease-in-out cursor-pointer ${
          isDragging ? 'border-primary bg-primary/10 scale-[1.01]' : 'border-white/10 hover:border-primary/50 hover:bg-white/[0.02]'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => !file && fileInputRef.current?.click()}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          className="hidden" 
          onChange={handleChange}
          accept="image/*,video/*"
        />
        
        <AnimatePresence mode="wait">
          {!file ? (
            <motion.div 
              key="upload-prompt"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="flex flex-col items-center text-center pointer-events-none"
            >
              <div className="p-4 bg-primary/10 rounded-full mb-3 group-hover:scale-110 transition-transform">
                <UploadCloud className="w-8 h-8 text-primary" />
              </div>
              <p className="mb-1 text-sm text-foreground/90 font-semibold">
                <span className="text-primary hover:underline">Click to upload</span> or drag & drop media
              </p>
              <p className="text-xs text-foreground/50 mb-3">JPG, PNG, WEBP, MP4, MOV (MAX 100MB)</p>
            </motion.div>
          ) : (
            <motion.div 
              key="file-info"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center w-full max-w-xl z-10"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between w-full p-4 bg-secondary/40 rounded-xl border border-white/10 shadow-lg">
                <div className="flex items-center space-x-4 overflow-hidden">
                  <div className="p-2.5 bg-primary/20 text-primary rounded-lg shrink-0">
                    <FileIcon className="w-6 h-6" />
                  </div>
                  <div className="text-left overflow-hidden">
                    <p className="text-sm font-medium text-foreground truncate max-w-[240px] sm:max-w-[340px]">
                      {file.name}
                    </p>
                    <p className="text-xs text-foreground/50">
                      {(file.size / (1024 * 1024)).toFixed(2)} MB • {file.type || "Media file"}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={clearFile}
                  className="p-2 text-foreground/50 hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors shrink-0"
                  title="Remove file"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              {!result && (
                <button 
                  onClick={handleAnalyze}
                  disabled={isUploading}
                  className="mt-5 px-8 py-3 bg-primary text-primary-foreground text-sm font-semibold rounded-xl hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_20px_rgba(59,130,246,0.4)] flex items-center gap-2"
                >
                  {isUploading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Performing Biometric & ELA Forensics...
                    </>
                  ) : (
                    <>
                      <Scan className="w-4 h-4" />
                      Run Forensic Analysis
                    </>
                  )}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Quick Test Preset Button */}
      {!file && (
        <div className="flex justify-center mt-3">
          <button
            onClick={(e) => { e.stopPropagation(); loadSampleImage(); }}
            className="text-xs text-primary/80 hover:text-primary flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/5 hover:bg-primary/10 border border-primary/20 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Load Sample Forensic Test Image
          </button>
        </div>
      )}

      {/* Error Banner */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 text-sm text-destructive flex items-center gap-2 bg-destructive/10 p-4 rounded-xl border border-destructive/20"
          >
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Forensic Results Dashboard */}
      <AnimatePresence>
        {result && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 space-y-6"
          >
            {/* Top Toolbar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-success" />
                <h3 className="text-lg font-bold">Forensic Verification Report</h3>
                <span className="text-xs text-foreground/40 hidden sm:inline">({result.filename})</span>
              </div>
              <button
                onClick={clearFile}
                className="text-xs text-foreground/50 hover:text-foreground flex items-center gap-1.5 px-3 py-1.5 bg-secondary/30 rounded-lg hover:bg-secondary/50 transition-all border border-white/5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Test Another File
              </button>
            </div>

            {/* 2-Column Main Forensics Display */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Metrics & Indicators */}
              <div className="lg:col-span-6 space-y-4">
                {/* AI Probability Card */}
                <div className={`p-5 rounded-2xl border ${getRiskColor(result.ai_probability)} transition-all shadow-lg`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs uppercase tracking-widest font-semibold opacity-80">AI Manipulation Probability</span>
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div className="flex items-baseline gap-3">
                    <span className="text-4xl font-black">
                      {(result.ai_probability * 100).toFixed(0)}%
                    </span>
                    <span className="text-sm font-semibold opacity-90">
                      {getRiskLabel(result.ai_probability)}
                    </span>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full bg-black/20 h-2.5 rounded-full mt-4 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-700 ${
                        result.ai_probability > 0.65 ? 'bg-destructive' : result.ai_probability > 0.35 ? 'bg-yellow-400' : 'bg-success'
                      }`}
                      style={{ width: `${Math.max(5, result.ai_probability * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Biometrics & Demographics */}
                <div className="glass-card">
                  <h4 className="text-sm font-bold text-foreground/80 mb-3 flex items-center gap-2">
                    <Scan className="w-4 h-4 text-primary" />
                    Facial & Biometric Recognition
                  </h4>
                  {result.faces && result.faces.length > 0 ? (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-secondary/30 p-3 rounded-xl border border-white/5">
                        <p className="text-xs text-foreground/50 mb-1">Faces Located</p>
                        <p className="text-xl font-bold text-foreground">{result.faces.length}</p>
                      </div>
                      <div className="bg-secondary/30 p-3 rounded-xl border border-white/5">
                        <p className="text-xs text-foreground/50 mb-1">Demographic Profile</p>
                        <p className="text-sm font-semibold text-foreground">
                          {result.faces[0].attributes.age} yrs • {result.faces[0].attributes.gender}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-foreground/50 italic bg-secondary/20 p-3 rounded-xl">
                      No facial landmarks detected in the sample frame.
                    </p>
                  )}
                </div>

                {/* Discrepancies List */}
                {result.discrepancies && result.discrepancies.length > 0 && (
                  <div className="glass-card">
                    <h4 className="text-sm font-bold text-foreground/80 mb-3 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      Forensic Discrepancies
                    </h4>
                    <ul className="space-y-2">
                      {result.discrepancies.map((d, i) => (
                        <li key={i} className="text-xs text-foreground/80 flex items-start gap-2.5 bg-secondary/20 p-2.5 rounded-lg border border-white/5">
                          <span className="text-primary font-bold mt-0.5">•</span>
                          <span className="leading-relaxed">{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Right Column: Visual Heatmap & Evidence Inspector */}
              <div className="lg:col-span-6 glass-card flex flex-col items-center">
                <div className="flex items-center justify-between w-full mb-3">
                  <h4 className="text-sm font-bold text-foreground/80 flex items-center gap-2">
                    <Eye className="w-4 h-4 text-accent" />
                    Forensic Inspection View
                  </h4>
                  {previewUrl && result.manipulation_heatmap && (
                    <div className="flex items-center bg-secondary/40 rounded-lg p-1 border border-white/5">
                      <button
                        onClick={() => setActiveView("heatmap")}
                        className={`text-xs px-2.5 py-1 rounded-md transition-all font-medium ${
                          activeView === "heatmap" ? 'bg-primary text-white shadow' : 'text-foreground/60 hover:text-white'
                        }`}
                      >
                        ELA Heatmap
                      </button>
                      <button
                        onClick={() => setActiveView("original")}
                        className={`text-xs px-2.5 py-1 rounded-md transition-all font-medium ${
                          activeView === "original" ? 'bg-primary text-white shadow' : 'text-foreground/60 hover:text-white'
                        }`}
                      >
                        Original Media
                      </button>
                    </div>
                  )}
                </div>

                {/* Display container */}
                <div className="relative w-full aspect-[4/3] max-h-[360px] bg-black/60 rounded-xl overflow-hidden border border-white/10 flex items-center justify-center">
                  {activeView === "heatmap" && result.manipulation_heatmap ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img 
                      src={result.manipulation_heatmap} 
                      alt="Error Level Analysis Heatmap" 
                      className="w-full h-full object-contain"
                    />
                  ) : previewUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img 
                      src={previewUrl} 
                      alt="Original Evidence" 
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <p className="text-xs text-foreground/50">Heatmap visualization unavailable for this media stream.</p>
                  )}

                  {/* Overlay legend tag */}
                  <div className="absolute bottom-2 left-2 right-2 bg-black/80 backdrop-blur-md p-2 rounded-lg border border-white/10 text-[11px] text-center text-foreground/70">
                    {activeView === "heatmap" 
                      ? "High-contrast color deviations indicate localized resaving, splicing, or generative AI infill."
                      : "Source media resolution and geometry inspection view."}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
