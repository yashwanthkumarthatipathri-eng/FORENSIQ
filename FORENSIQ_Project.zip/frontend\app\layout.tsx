import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FORENSIQ | AI-Powered Forensics & Live Fact-Checking Platform",
  description: "FORENSIQ: Advanced multi-modal AI media forensics, Error Level Analysis (ELA), deepfake detection, and live news fact-checking platform.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-[#0f172a] text-[#f8fafc] antialiased selection:bg-primary/30 selection:text-primary-foreground">
        {children}
      </body>
    </html>
  );
}