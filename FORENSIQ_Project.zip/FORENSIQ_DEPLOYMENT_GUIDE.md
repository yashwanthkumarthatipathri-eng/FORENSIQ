# FORENSIQ | GitHub Upload & Live URL Deployment Guide

A step-by-step master guide to upload your source code to GitHub and deploy permanent, free HTTPS live URLs on Vercel and Render.

---

## 🌐 Current Active Live URLs (Running Now)

Your local services are actively broadcasting over secure live tunnels:
1. **Branded FORENSIQ URL**: [https://forensiq.loca.lt](https://forensiq.loca.lt)  
   *(If prompted for Tunnel Password / IP, enter: `157.50.87.50`)*
2. **Cloudflare Global Tunnel (Instant 1-Click)**: [https://laugh-june-expected-continue.trycloudflare.com](https://laugh-june-expected-continue.trycloudflare.com)  
   *(Direct access, zero prompts, worldwide HTTP 200 OK)*

---

## 📦 Step 1: Clean GitHub Upload Archive

We prepared a clean, pre-packaged ZIP archive in your project directory:
```
c:\Users\yashw\OneDrive\Documents\new p1\FORENSIQ_GitHub_Upload.zip
```
* **Why?** Raw project folders contain `node_modules` (300 MB) and `venv` (400 MB), which GitHub will reject due to file size limits. This ZIP contains **only** clean source code ready for immediate upload.

---

## 🚀 Step 2: Upload to GitHub

### Option A: Upload via Browser (Easiest - 1 Minute)
1. Go to [https://github.com/new](https://github.com/new) and sign in.
2. Repository name: **`forensiq`**
3. Select **Public**.
4. Do **not** check "Add a README file" (a complete README is already included).
5. Click **Create repository**.
6. On the empty repository page, click the link: **"uploading an existing file"**.
7. Unzip `FORENSIQ_GitHub_Upload.zip` and drag all files (`frontend`, `backend`, `README.md`, etc.) into the GitHub upload area.
8. Click **Commit changes**.

### Option B: Upload via Git Command Line
```powershell
cd "c:\Users\yashw\OneDrive\Documents\new p1"
git init
git add .
git commit -m "Initial commit: FORENSIQ full-stack platform"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/forensiq.git
git push -u origin main
```

---

## ⚡ Step 3: Deploy Frontend on Vercel (Get Permanent Live URL)

Vercel provides free global hosting with automatic SSL:
1. Go to [https://vercel.com](https://vercel.com) and log in with GitHub.
2. Click **Add New...** → **Project**.
3. Locate your **`forensiq`** repository and click **Import**.
4. In Project Settings:
   - **Framework Preset**: Next.js (auto-detected)
   - **Root Directory**: Click "Edit" and select **`frontend`**
5. Click **Deploy**.

🎉 **Result**: Within 60 seconds, you get your permanent live URL:  
👉 **`https://forensiq.vercel.app`** (or your chosen custom domain).

---

## 🛡️ Step 4: Deploy Backend on Render (Get Permanent Live API URL)

Render provides free hosting for FastAPI & Python backends:
1. Go to [https://render.com](https://render.com) and sign in with GitHub.
2. Click **New +** → **Web Service**.
3. Select your **`forensiq`** repository.
4. Render automatically detects the pre-configured `backend/Dockerfile` and `render.yaml`.
5. Select the **Free** instance plan.
6. Click **Create Web Service**.

🎉 **Result**: Within 2–3 minutes, your backend API is live at:  
👉 **`https://forensiq-api.onrender.com`**

### Connecting Frontend to Backend
In your Vercel Dashboard → **Settings** → **Environment Variables**, add:
- **Key**: `NEXT_PUBLIC_BACKEND_URL`
- **Value**: `https://forensiq-api.onrender.com`
Then click **Redeploy**.

---

## 📄 Downloadable Documents Included in Your Project
* 🌐 **Interactive Guide with PDF Export**: [FORENSIQ_DEPLOYMENT_GUIDE.html](file:///c:/Users/yashw/OneDrive/Documents/new%20p1/FORENSIQ_DEPLOYMENT_GUIDE.html)
* 📝 **Markdown Guide**: [FORENSIQ_DEPLOYMENT_GUIDE.md](file:///c:/Users/yashw/OneDrive/Documents/new%20p1/FORENSIQ_DEPLOYMENT_GUIDE.md)
* 📦 **Clean Upload ZIP**: [FORENSIQ_GitHub_Upload.zip](file:///c:/Users/yashw/OneDrive/Documents/new%20p1/FORENSIQ_GitHub_Upload.zip)
