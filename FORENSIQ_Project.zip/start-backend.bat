﻿@echo off
title AI M0DULE - FastAPI Backend (Port 8000)
cd /d "%~dp0backend"
echo ========================================================
echo Starting AI M0DULE Verification Backend on port 8000...
echo API Docs: http://localhost:8000/docs
echo Health Check: http://localhost:8000/health
echo ========================================================
call venv\Scripts\activate.bat
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
pause
