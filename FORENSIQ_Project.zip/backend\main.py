﻿from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import verify

app = FastAPI(
    title="AI M0DULE Backend", 
    version="1.0.0",
    description="Advanced AI media forensics and real-time news verification backend."
)

# Robust CORS configuration for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:3005",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://127.0.0.1:3005",
    ],
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(verify.router, prefix="/api/verify", tags=["Verify"])

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "AI M0DULE Backend",
        "version": "1.0.0",
        "modules": {
            "media_engine": "online",
            "news_engine": "online"
        }
    }

@app.get("/")
async def root():
    return {
        "name": "AI M0DULE Verification API",
        "docs": "/docs",
        "health": "/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
