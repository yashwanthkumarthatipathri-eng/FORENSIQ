"use client";

import { useState } from "react";
import UploadZone from "@/components/UploadZone";
import NewsChecker from "@/components/NewsChecker";
import AuthModal from "@/components/AuthModal";
import SplitFlapText from "@/components/SplitFlapText";
import TrueFocus from "@/components/TrueFocus";
import { Shield, Fingerprint, Activity, Image as ImageIcon, Newspaper, CheckCircle, Download, FileText, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState<"media" | "news">("media");

  return (
    <main className="min-h-screen relative overflow-hidden bg-background text-foreground selection:bg-primary/30">
      {/* Dynamic Ambient Background Glow Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] bg-primary/15 blur-[140px] rounded-full mix-blend-screen" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] bg-accent/15 blur-[140px] rounded-full mix-blend-screen" />
        <div className="absolute top-[40%] right-[30%] w-[25%] h-[25%] bg-blue-500/10 blur-[160px] rounded-full mix-blend-screen" />
      </div>

      {/* Navigation Bar */}
      <nav className="relative z-20 border-b border-white/5 bg-background/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-primary/20 rounded-xl border border-primary/30 text-primary shadow-[0_0_15px_rgba(59,130,246,0.3)]">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-black tracking-wider text-foreground">FORENSIQ</span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-primary block -mt-1">
                AI Forensics & Fact-Checking
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <div className="flex items-center gap-2 text-xs text-foreground/60 px-3.5 py-2 bg-secondary/30 rounded-full border border-white/5 backdrop-blur-md">
              <Activity className="w-3.5 h-3.5 text-success animate-pulse" />
              <span className="hidden sm:inline">Engines Online • v1.0</span>
            </div>

            <a
              href="/FORENSIQ_GitHub_Upload.zip"
              download="FORENSIQ_GitHub_Upload.zip"
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-semibold transition-all"
              title="Download GitHub Ready ZIP Archive"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP</span>
            </a>

            <button 
              onClick={() => setIsAuthOpen(true)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all text-xs font-semibold ${
                isAuthenticated
                  ? "bg-success/15 border-success/30 text-success"
                  : "bg-primary/10 hover:bg-primary/20 text-primary border-primary/30 shadow-[0_0_10px_rgba(59,130,246,0.2)]"
              }`}
            >
              {isAuthenticated ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Passkey Verified</span>
                </>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4" />
                  <span className="hidden sm:inline">WebAuthn Access</span>
                </>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main Container */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 py-8 sm:py-10">
        {/* Hero Header */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold uppercase tracking-widest mb-4"
          >
            Digital Truth & Provenance Guard
          </motion.div>

          {/* Integrated TrueFocus Component configured with 'THE FORENSIQ' */}
          <div className="my-4 flex justify-center">
            <TrueFocus 
              sentence="THE FORENSIQ"
              manualMode={false}
              blurAmount={5}
              borderColor="red"
              animationDuration={2}
              pauseBetweenAnimations={1}
            />
          </div>
        </div>

        {/* Integrated SplitFlapText Mechanical Departure Board */}
        <div className="flex flex-col items-center justify-center my-6 overflow-x-auto py-2">
          <div className="p-3 bg-secondary/30 rounded-2xl border border-white/10 shadow-xl backdrop-blur-md">
            <SplitFlapText
              words={['LAUNCH READY', 'SYNC ONLINE', 'SIGNAL LIVE', 'FORENSICS ACTIVE', 'AI VERIFIED']}
              flipDuration={0.12}
              stagger={0.06}
              cycleDelay={2400}
              charset="alphanumeric"
              flipsPerChar={8}
              tileColor="#111827"
              textColor="#f8fafc"
              tileRadius={8}
              gap={6}
              fontSize={28}
              loop
              padTo={16}
            />
          </div>
        </div>

        {/* GitHub & Deployment Download Bar */}
        <div className="flex flex-wrap items-center justify-center gap-3 my-6">
          <a
            href="/FORENSIQ_GitHub_Upload.zip"
            download="FORENSIQ_GitHub_Upload.zip"
            className="flex items-center gap-2.5 px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs sm:text-sm shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <Download className="w-4 h-4" />
            <span>Download GitHub Package (.ZIP)</span>
          </a>

          <a
            href="/FORENSIQ_DEPLOYMENT_GUIDE.html"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary/60 hover:bg-secondary border border-white/10 text-foreground font-semibold text-xs sm:text-sm backdrop-blur-md transition-all hover:border-white/20"
          >
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Open Deployment Guide (PDF/HTML)</span>
            <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
          </a>
        </div>

        {/* Tab Selection */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center p-1.5 bg-secondary/40 rounded-2xl border border-white/10 backdrop-blur-md shadow-lg">
            <button
              onClick={() => setActiveTab("media")}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === "media" 
                  ? 'bg-primary text-primary-foreground shadow-[0_0_15px_rgba(59,130,246,0.4)]' 
                  : 'text-foreground/60 hover:text-foreground hover:bg-white/5'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              Media Forensics & ELA
            </button>
            <button
              onClick={() => setActiveTab("news")}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === "news" 
                  ? 'bg-primary text-primary-foreground shadow-[0_0_15px_rgba(59,130,246,0.4)]' 
                  : 'text-foreground/60 hover:text-foreground hover:bg-white/5'
              }`}
            >
              <Newspaper className="w-4 h-4" />
              Live News Fact-Check
            </button>
          </div>
        </div>

        {/* Interactive Workspace Area */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="glass-card"
        >
          {activeTab === "media" ? (
            <div className="flex flex-col items-center">
              <div className="text-center mb-6 max-w-xl">
                <h2 className="text-xl font-bold mb-1">Media Evidence Forensics</h2>
                <p className="text-xs sm:text-sm text-foreground/50 leading-relaxed">
                  Upload images or video clips to detect AI generative infill, splicing compression artifacts, 
                  and biometric consistency across keyframes.
                </p>
              </div>
              <UploadZone />
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <div className="text-center mb-6 max-w-xl">
                <h2 className="text-xl font-bold mb-1">Live Fact-Checking Engine</h2>
                <p className="text-xs sm:text-sm text-foreground/50 leading-relaxed">
                  Submit viral statements or headlines to cross-reference with live syndicated news engines 
                  and discover source discrepancies.
                </p>
              </div>
              <NewsChecker />
            </div>
          )}
        </motion.div>
      </div>

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        onAuthenticated={() => setIsAuthenticated(true)}
      />
    </main>
  );
}