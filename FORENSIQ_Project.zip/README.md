# FORENSIQ | AI-Powered Forensics & Live Fact-Checking Platform

## 🌍 Live Public Access (Worldwide)

1. **Branded Subdomain**: 👉 **[https://forensiq.loca.lt](https://forensiq.loca.lt)** *(Password if prompted: `157.50.87.50`)*
2. **Cloudflare Global Tunnel**: 👉 **[https://laugh-june-expected-continue.trycloudflare.com](https://laugh-june-expected-continue.trycloudflare.com)** *(Instant 1-click access)*

## 📄 Deployment Guide
- 🌐 [Interactive HTML Guide (Print / Save as PDF)](./FORENSIQ_DEPLOYMENT_GUIDE.html)
- 📝 [GitHub & Cloud Deployment Guide (Markdown)](./FORENSIQ_DEPLOYMENT_GUIDE.md)
- 📦 Clean Ready-to-Upload ZIP: `FORENSIQ_GitHub_Upload.zip`

An advanced full-stack verification web platform built to combat digital deception, synthetic deepfakes, and viral misinformation.

---

## 🌟 Key Capabilities

### 1. Media Evidence Forensics & Error Level Analysis (ELA)
- **Error Level Analysis (ELA)**: Computes pixel-level compression noise variance and identifies localized resaving, splicing, and generative AI infill.
- **Dynamic Heatmap Visualization**: Renders color-mapped manipulation overlays (using OpenCV `COLORMAP_JET`) comparing natural vs. altered pixel boundaries.
- **Biometric Face Verification**: Employs PyTorch and OpenCV Haar cascade facial recognition to track facial landmarks, counts, and spatial demographic profiles.
- **Video Forensics**: Real temporal frame extraction sampling video sequences across time to detect compression shifts and face transitions.
- **Instant Test Sample**: Features an on-the-fly synthetic sample generator button so you can test the forensics engine without needing an image file ready.

### 2. Live Fact-Checking Engine
- **Live Search Cross-Referencing**: Queries DuckDuckGo and syndicated news indices across global fact-check networks (Google News, Reuters, AP News, NDTV, Times of India, etc.).
- **Truthfulness Score (0–100%)**: Evaluates corroboration versus debunking signals to calculate a clear confidence score.
- **Discrepancy Breakdown**: Highlights conflicting statements, timeline inconsistencies, and verified confirmations.
- **Direct Source Citations**: Presents interactive cards with headlines, snippets, and verified external links.
- **Quick Preset Examples**: One-click test claims covering science, politics, and common online myths.

### 3. FIDO2 / WebAuthn Biometric Security
- **Biometric Passkey Gateway**: Seamlessly interacts with `navigator.credentials` (Windows Hello, Touch ID, or Hardware Security Keys) with high-tech visual feedback.
- **Zero-Trust Access**: Cryptographic authentication challenge verification.

---

## 🚀 Quick Start Guide

### Prerequisites
- **Python**: Installed (3.11 recommended, pre-configured in `backend/venv`)
- **Node.js**: Installed (v20+ recommended, pre-configured in your user environment)

### Option 1: One-Click Startup (Windows)
Double-click:
1. `start-backend.bat` (Starts FastAPI on `http://localhost:8000`)
2. `start-frontend.bat` (Starts Next.js on `http://localhost:3000`)

Or run `start-all.bat`.

---

### Option 2: Manual Startup

#### 1. Backend (FastAPI + PyTorch)
```powershell
cd backend
venv\Scripts\activate
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
- API Documentation: `http://localhost:8000/docs`
- Health Check: `http://localhost:8000/health`

#### 2. Frontend (Next.js 14 + Tailwind CSS)
```powershell
cd frontend
npm run dev
```
- Web Application: `http://localhost:3000` (or `http://localhost:3001`)

---

## 🧪 Running the Test Suites

### Backend Unit & Integration Tests (Pytest)
```powershell
cd backend
venv\Scripts\pytest tests/ -v
```
**Results**: 7/7 tests passing (100% pass rate).
- Health check verification
- Empty & whitespace claim handling (HTTP 400)
- News verification pipeline & heuristic fallback
- Media image verification (mock & real end-to-end ELA JPEG analysis)
- Sample claims endpoint

### Frontend Build Verification
```powershell
cd frontend
npm run build
```
**Results**: Compiled successfully with 0 TypeScript and 0 build errors.

---

## 📂 Project Architecture

```
new p1/
├── backend/
│   ├── venv/                 # Python 3.11 virtual environment
│   ├── main.py               # FastAPI application & CORS config
│   ├── requirements.txt      # Python dependencies
│   ├── services/
│   │   ├── media_engine.py   # ELA, facial biometrics, & video forensics
│   │   └── news_engine.py    # DuckDuckGo search, Gemini AI, & heuristic fact-checker
│   ├── routers/
│   │   └── verify.py         # /api/verify/news, /media, /samples
│   └── tests/
│       └── test_verify.py    # Pytest test suite (100% passing)
├── frontend/
│   ├── app/
│   │   ├── layout.tsx        # Root layout with dark mode theme
│   │   ├── page.tsx          # Main interactive forensics dashboard
│   │   └── globals.css       # Tailwind CSS & glassmorphism styling
│   ├── components/
│   │   ├── UploadZone.tsx    # File uploader, dual inspection & heatmap viewer
│   │   ├── NewsChecker.tsx   # Fact-checking interface with radial score & citations
│   │   └── AuthModal.tsx     # WebAuthn & biometric scanner modal
│   ├── package.json          # Frontend dependencies
│   ├── next.config.js        # Next.js configuration
│   └── tailwind.config.js    # Design system and theme tokens
├── start-backend.bat         # Fast launcher for backend
├── start-frontend.bat        # Fast launcher for frontend
├── start-all.bat             # Launcher for both services
└── README.md                 # Project documentation
```
